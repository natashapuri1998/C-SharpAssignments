﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************ PROGRAM AREA OF CIRCLE *************");
            AreaOfCircle ac = new AreaOfCircle();
            ac.AreaCircle();
            Console.WriteLine("************ PROGRAM DOLLER RUPEES *************");
            DollarRupee dr = new DollarRupee();
            dr.DollerRupees();
            Console.WriteLine("************ PROGRAM TYPECASTING *************");
            TypeCasting tc = new TypeCasting();
            tc.CharToAscii();
            Console.ReadLine();
        }
    }
}
