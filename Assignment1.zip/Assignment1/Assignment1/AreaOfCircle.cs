﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class AreaOfCircle
    {
        public void AreaCircle()
        {
            const double PI = 3.14;
            Console.WriteLine("Enter the value of radius:");
            int radius=Convert.ToInt32(Console.ReadLine());
            double area = PI * radius * radius;
            Console.WriteLine("Area of Circle :{0}",area);
            Console.ReadLine();
        }
    }
}
