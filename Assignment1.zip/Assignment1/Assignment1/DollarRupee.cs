﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class DollarRupee
    {
        public void DollerRupees()
        {
            Console.WriteLine("Enter the dollar value:");
            int dollar = Convert.ToInt32(Console.ReadLine());
            double rupee = dollar * 71.06;
            Console.WriteLine("Ruppee Value:{0}", rupee);
            Console.ReadLine();

            Console.WriteLine("Enter the ruppee value:");
            int rupee1= Convert.ToInt32(Console.ReadLine());
            
            double dollar1 = rupee1/ 71.06;
            Console.WriteLine("Dollar value:{0}",dollar1);
            Console.ReadLine();
        }
        
    }

}
