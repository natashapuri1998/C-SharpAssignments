﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class TypeCasting
    {
        public void CharToAscii()
        {
            Console.WriteLine("Enter the Ascii Char:");
            char c = Convert.ToChar(Console.ReadLine());
            
            int a = (int)c;
            Console.WriteLine("Integer Value:{0}",a);
            Console.ReadLine();

            Console.WriteLine("Enter the integer value:");

            int b = Convert.ToInt32(Console.ReadLine());
            char n = (char)b;
            Console.WriteLine("Ascii value:{0}",n);
            Console.ReadLine();
        }
    }
}
