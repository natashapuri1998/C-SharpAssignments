﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************** PROGRAM REVERSE NUMBERS ****************");
            NumbersInReverse nr = new NumbersInReverse();
            nr.NumRev();
            Console.WriteLine("************** PROGRAM ODD NUMBERS FOR EACH ****************");
            OddNumbersUsingforeach ofe = new OddNumbersUsingforeach();
            ofe.OddForEach();
            Console.WriteLine("************** PROGRAM ODD NUMBERS DO WHILE ****************");
            OddNumbersUsingDoWhile odw = new OddNumbersUsingDoWhile();
            odw.OddDoWhile();
            Console.WriteLine("************** PROGRAM EVEN NUMBERS FOR EACH ****************");
            EvenNumberforeach efe = new EvenNumberforeach();
            efe.EvenFor();
            Console.WriteLine("************** PROGRAM PRINT TABLE ****************");
            TableUsingFor tb = new TableUsingFor();
            tb.Tables();
            Console.ReadLine();
        }
    }
}
