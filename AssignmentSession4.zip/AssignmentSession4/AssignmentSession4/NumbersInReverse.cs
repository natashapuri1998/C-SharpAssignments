﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession4
{
    class NumbersInReverse
    {
        public void NumRev()
        {
            for(int i=50;i>=1;i--)
            {
                Console.WriteLine(i);
            }
            Console.ReadLine();
        }
    }
}
