﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession4
{
    class OddNumbersUsingDoWhile
    {
        public void OddDoWhile()
        {
            int i=1;
            do
            {
                if ((i % 2) != 0)
                {
                    Console.WriteLine(i);

                }
                i++;
                

                
            }
            while (i <= 50);
            
        }
    }
}
