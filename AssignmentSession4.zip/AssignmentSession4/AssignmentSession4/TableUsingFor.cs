﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession4
{
    class TableUsingFor
    {
        public void Tables()
        {
            Console.WriteLine("Enter the no");
            int no=Convert.ToInt32(Console.ReadLine());
            int sum = 0;
            Console.WriteLine("Table:");
            for (int i=1;i<=10;i++)
            {
                sum = sum + no;
                Console.WriteLine(sum);
            }
            Console.ReadLine();
        }
    }
}
