﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************* PROGRAM MAJOR MINOR IFELSE ***************");
            MajorMinor mj1 = new MajorMinor();
            mj1.MajorMinorIfElse();
            Console.WriteLine("************* PROGRAM MAJOR MINOR TERNARY ***************");
            MajorMinorTernary mj2 = new MajorMinorTernary();
            mj2.MajorMinorTer();
            Console.WriteLine("************* PROGRAM PERCENTAGE GRADE ***************");
            PercentageGrade pg = new PercentageGrade();
            pg.Grades();
            Console.WriteLine("************* PROGRAM DISPLAY DAY ***************");
            DayDisplay dd = new DayDisplay();
            dd.DaysDisplay();
            Console.ReadLine();
        }
    }
}
