﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession3
{
    class MajorMinor
    {
        public void MajorMinorIfElse()
        {
            Console.WriteLine("Enter the age of person for whom you want to find minor or major");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age>=18)
            {
                Console.WriteLine("Person is Major");
            }
            else
            {
                Console.WriteLine("Person is Minor");
            }
            Console.ReadLine();
        }
    }
}
