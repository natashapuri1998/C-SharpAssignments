﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession3
{
    class PercentageGrade
    {
        public void Grades()
        {
            Console.WriteLine("Enter your percentage:");
            double per = Convert.ToDouble(Console.ReadLine());
            if(per>=75)
            {
                Console.WriteLine("Distinction");
            }
            else if (per >= 60 && per <75)
            {
                Console.WriteLine("A Grade");
            }
            else if (per >= 50 && per <60)
            {
                Console.WriteLine("B Grade");
            }
            else if (per >= 40 && per <50)
            {
                Console.WriteLine("C Grade");
            }
            else if (per >= 35 && per <40)
            {
                Console.WriteLine("D Grade");
            }
            else
            {
                Console.WriteLine("Fails");
            }
            Console.ReadLine();
        }
    }
}
