﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession3
{
    class MajorMinorTernary
    {
        public void MajorMinorTer()
        {
            Console.WriteLine("Enter the age of person for whom you want to find minor or major");
            int age = Convert.ToInt32(Console.ReadLine());
             string str=(age >= 18)? "Person is Major":"Person is Minor";
            Console.WriteLine(str);
            Console.ReadLine();
        }
    }
}
