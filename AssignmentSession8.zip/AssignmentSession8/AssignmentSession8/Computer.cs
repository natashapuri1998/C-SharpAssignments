﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    abstract class Computer
    {
        public string BootUp()
        {
            return "Boot Up Function of Computer";
        }

        abstract public string ShutDown();
       
    }

    class SuperComputer : Computer
    {
        public override string ShutDown()
        {
            return "Shut Down Function of Super Computer";
        }
    }

    class MainFrameComputer : Computer
    {
        public override string ShutDown()
        {
            return "Shut Down Function of Main Frame Computer";
        }
    }


    class MicroComputer : Computer
    {
        public override string ShutDown()
        {
            return "Shut Down Function of Micro Computer";
        }
    }
}
