﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    class SavingAccount:IBankAccount
    {
        double balance = 0;
        public void Deposit(double amount)
        {
            balance = balance + amount;
            Console.WriteLine($"Amount Deposited for SavingAccount : {amount}  Balance is : {balance}");

        }

        public void Withdraw(double amount)
        {
            if(amount<=balance)
            {
                balance = balance - amount;
                Console.WriteLine($"Amount Withdrawn for SavingAccount : {amount} Balance is : {balance}");
            }
            else
            {
                Console.WriteLine($"Amount Exceeded balance       balance remaining : {balance}");
            }
            
        }
    }
}
