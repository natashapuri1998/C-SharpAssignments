﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    class User
    {
        private long id;
        private string name;
        private string emailid;
        private string dateOfBirth;

        public long UserId
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public string UserName
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }

        public string UserEmail
        {
            get
            {
                return emailid;
            }
            set
            {
                emailid = value;
            }
        }

        public string UserDateOfBirth
        {
            get
            {
                return dateOfBirth;
            }
            set
            {
                dateOfBirth = value;
            }
        }

        public User()
        {

        }

        public User(long id,string name, string emailid, string dateOfBirth)
        {
            this.id = id;
            this.name = name;
            this.emailid = emailid;
            this.dateOfBirth = dateOfBirth;
        }

        public override string ToString()
        {
            return string.Format("Id : {0} \n Name : {1} \n Email Id : {2} \n Date of birth : {3}", id,name,emailid,dateOfBirth);
        }

    }
}
