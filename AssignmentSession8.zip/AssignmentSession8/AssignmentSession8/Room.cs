﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    class Room
    {
        private int number; 
        private int floor;
        private string type;
        private int capacity;
        private DateTime bookedTime;
        private double price;

        public int RoomNumber
        {
            get
            {
                return number;
            }
            set
            {
                number = value;
            }
        }

        public int RoomFloor
        {
            get
            {
                return floor;
            }
            set
            {
                floor = value;
            }
        }

        public string RoomType
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }

        public int RoomCapacity
        {
            get
            {
                return capacity;
            }
            set
            {
                capacity = value;
            }
        }

        public DateTime RoomBookedTime
        {
            get
            {
                return bookedTime;
            }
            set
            {
                bookedTime = value;
            }
        }

        public double RoomPrice
        {
            get
            {
                return price;
            }
            set
            {
                price = value;
            }
        }


        public Room()
        {

        }

        public Room(int number,int floor,string type,int capacity,DateTime bookedTime,double price)
        {
            this.number=number;
            this.floor = floor;
            this.type=type;
            this.capacity=capacity;
            this.bookedTime=bookedTime;
            this.price=price;
        }

        public override string ToString()
        {
            return string.Format("Number : {0} \n Floor : {1} \n Type : {2} \n Capacity : {3} \n Booked Time : {4} \n Price : {5}",number,floor,type,capacity,bookedTime,price);
        }
    }
}
