﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*************Super Computer*************");
            SuperComputer sc = new SuperComputer();
           Console.WriteLine(sc.BootUp());
           Console.WriteLine(sc.ShutDown());
            Console.ReadLine();

            Console.WriteLine("*************Main Frame Computer*************");
            MainFrameComputer mfc = new MainFrameComputer();
            Console.WriteLine(mfc.BootUp());
            Console.WriteLine(mfc.ShutDown());
            Console.ReadLine();

            Console.WriteLine("*************Micro Computer*************");
            MicroComputer mc = new MicroComputer();
            Console.WriteLine(mc.BootUp());
            Console.WriteLine(mc.ShutDown());
            Console.ReadLine();

            Console.WriteLine("*****************Pen Using Sealed************************");
            Pen p = new Pen();
            Console.WriteLine(p.StartWriting());
            Console.WriteLine(p.StopWriting());
            Console.ReadLine();

            Console.WriteLine("*****************Hotel-Requirement************************");
            Console.WriteLine("Enter Room Number:");
            int number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Floor:");
            int floor = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Type:");
            string type = Console.ReadLine();
            Console.WriteLine("Enter Room Capacity:");
            int capacity = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Room Booked Time:");
            DateTime bookedTime = Convert.ToDateTime(Console.ReadLine());
            Console.WriteLine("Enter Room Price:");
            double price = Convert.ToDouble(Console.ReadLine());
            Room r = new Room(number,floor,type,capacity,bookedTime,price);
            Console.WriteLine(r.ToString());
            Console.ReadLine();

            Console.WriteLine("*****************Forum-Requirement************************");
            Console.WriteLine("Enter User Id:");
            long id = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("Enter User Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Email Id:");
            string emailid = Console.ReadLine();
            Console.WriteLine("Enter Date of Birth:");
            string dateOfBirth = Console.ReadLine();
            User u = new User(id, name, emailid, dateOfBirth);
            Console.WriteLine(u.ToString());
            Console.ReadLine();

            Console.WriteLine("****************Bank-Requirement******************");
            Console.WriteLine("**********For Saving Account**********");
            SavingAccount sa = new SavingAccount();
            Console.WriteLine("Enter amount to be deposited :");
            int amount = Convert.ToInt32(Console.ReadLine());
            sa.Deposit(amount);
            Console.WriteLine("Enter amount to be withdrawn :");
            int amnt = Convert.ToInt32(Console.ReadLine());
            sa.Withdraw(amnt);
            Console.WriteLine("**********For Current Account**********");
            CurrentAccount ca = new CurrentAccount();
            Console.WriteLine("Enter amount to be deposited :");
            int amount1 = Convert.ToInt32(Console.ReadLine());
            sa.Deposit(amount1);
            Console.WriteLine("Enter amount to be withdrawn :");
            int amnt1 = Convert.ToInt32(Console.ReadLine());
            sa.Withdraw(amnt1);
            Console.ReadLine();
        }
    }
}
