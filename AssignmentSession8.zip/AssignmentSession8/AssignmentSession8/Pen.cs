﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession8
{
    public sealed class Pen
    {
        public string StartWriting()
        {
            return "Pen starts writing";
        }

        public string StopWriting()
        {
            return "Pen stops writing";
        }
    }
}
