﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GST;

namespace ConsoleUsingGST
{
    class Program
    {
        static void Main(string[] args)
        {
            CalcGst g = new CalcGst();
            Console.WriteLine("Enter Amount");
            double amt = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Percentge");
            int per = Convert.ToInt32(Console.ReadLine());
            double gst;
            Console.WriteLine("Total Amount : {0}", g.CalculateGst(amt, per, out gst));
            Console.WriteLine("GST : {0}", gst);
            Console.ReadLine();
        }
    }
}
