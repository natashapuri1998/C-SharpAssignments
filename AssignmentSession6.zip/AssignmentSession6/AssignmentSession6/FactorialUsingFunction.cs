﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class FactorialUsingFunction
    {
        public int Factorial(int no)
        {
            int fact = 1;
           for(int i=1;i<=no;i++)
            {
                fact = fact * i;
            }
            return fact;
        }

        public void FactFun()
        {
            FactorialUsingFunction f = new FactorialUsingFunction();
            Console.WriteLine("Enter the no:");
            int no=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Factorial is:");
           Console.WriteLine( f.Factorial(no));
            Console.ReadLine();
        }
    }
}
