﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************** PROGRAM FACTORIAL ****************");
            FactorialUsingFunction f = new FactorialUsingFunction();
            f.FactFun();
            Console.WriteLine("************** PROGRAM SIMPLE INTREST USING FUNCTION ****************");
            SimpleInterestUsingFunction sf = new SimpleInterestUsingFunction();
            sf.SimpleFun();
            Console.WriteLine("************** PROGRAM SIMPLE INTREST USING OUT ****************");
            SimpleInterestTotalAmountUsingOut so = new SimpleInterestTotalAmountUsingOut();
            so.SimpleOut();
            Console.WriteLine("************** PROGRAM JAGGED USING FUNCTION ****************");
            JaggedArrayUsingFunc jf = new JaggedArrayUsingFunc();
            jf.JaggedFunc();
            Console.WriteLine("************** PROGRAM GST USING OUT ****************");
            GSTAmountUsingOut gs = new GSTAmountUsingOut();
            gs.GST();
            Console.ReadLine();
        }
    }
}
