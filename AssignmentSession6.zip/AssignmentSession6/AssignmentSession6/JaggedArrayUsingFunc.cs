﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class JaggedArrayUsingFunc
    {

        public void Search(int[][] a, int ele)
        {
            int found = 0;
            for (int i = 0; i < 2; i++)
            {
                foreach (int t in a[i])
                {
                    if (t == ele)
                    {
                        found = 1;
                    }
                }
            }
            if(found==1)
            {
                Console.WriteLine("{0} element found", ele);
            }
            else
            {
                        Console.WriteLine("{0} element not found",ele);
            }
                
            
        }

        public void JaggedFunc()
        {
                   
      
        int[][] a = new int[2][];
        a[0] = new int[] { 10,20,30};
        a[1] = new int[] { 40, 50 };
        Console.WriteLine("Jagged Array:");
        for(int i=0;i<2;i++)
        {
            foreach(int temp in a[i])
            {
                Console.Write("{0} \t",temp);
            }
                Console.WriteLine();
        }
        Console.WriteLine("Enter an element:");
        int ele = Convert.ToInt32(Console.ReadLine());
            JaggedArrayUsingFunc j = new JaggedArrayUsingFunc();
            j.Search(a, ele);
            Console.ReadLine();
      
    }

    }
}
