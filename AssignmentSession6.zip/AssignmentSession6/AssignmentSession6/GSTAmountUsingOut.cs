﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class GSTAmountUsingOut
    {
        public double GstAmount(double amount,int gst=1)
        {
            double result;
            result = (amount * gst) / 100;
            return result;
        }
        public void GST()
        {
            Console.WriteLine("Enter the amount:");
            double amt = Convert.ToDouble(Console.ReadLine());
            GSTAmountUsingOut g = new GSTAmountUsingOut();
            Console.WriteLine("GST(1%) Amount is : {0}", g.GstAmount(amt));
            Console.WriteLine("GST(5%) Amount is : {0}", g.GstAmount(amt,5));
            Console.ReadLine();
        }
    }
}
