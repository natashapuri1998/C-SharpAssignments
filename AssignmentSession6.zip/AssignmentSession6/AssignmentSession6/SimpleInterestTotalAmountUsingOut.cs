﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class SimpleInterestTotalAmountUsingOut
    {
        public double SimpleInterest(double p, double r, int t, out double interest)
        {
            double result;
            interest = (p * r * t) / 100;
            result = p + interest;
            return result;
        }

        public void SimpleOut()
        {
            Console.WriteLine("Enter principal amount");
            double p = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter rate of interest");
            double r = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter time");
            int t = Convert.ToInt32(Console.ReadLine());
            SimpleInterestTotalAmountUsingOut s = new SimpleInterestTotalAmountUsingOut();


            double interest1;
            Console.WriteLine( "Total Amount is : {0}",s.SimpleInterest(p, r, t,out interest1));
            Console.WriteLine("Simple Interest is : {0}",interest1);

            Console.ReadLine();
        }
    }
}
