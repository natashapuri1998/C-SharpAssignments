﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession6
{
    class SimpleInterestUsingFunction
    {
        public double SimpleInterest(double p,double r,int t)
        {
            double result;
            result = (p*r*t) / 100;
            return result;
        }

        public void SimpleFun()
        {
            Console.WriteLine("Enter principal amount");
            double p = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter rate of interest");
            double r = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter time");
            int t = Convert.ToInt32(Console.ReadLine());
            SimpleInterestUsingFunction s = new SimpleInterestUsingFunction();
            Console.WriteLine("Simple Interest is:");
            Console.WriteLine(s.SimpleInterest(p, r, t));
            Console.ReadLine();

          

        }
    }
}
