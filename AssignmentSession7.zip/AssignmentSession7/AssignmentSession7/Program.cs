﻿using System;

namespace AssignmentSession7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("****************Student Structure***************");
            Console.WriteLine("Enter Roll No:");
            int rno = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name:");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Gender(M/F):");
            char gender = Convert.ToChar(Console.ReadLine());
            Console.WriteLine("Enter Mobile No:");
            long mno = Convert.ToInt64(Console.ReadLine());
            Student stud = new Student(rno, name, gender, mno);
            Console.WriteLine("************************Student Details**********************************");
            stud.display();
            Console.ReadLine();

            Console.WriteLine("**********Cities Enum**********");
            foreach (string name1 in Enum.GetNames(typeof(Cities)))
            {
                Console.WriteLine(name1);
            }

            foreach (int std in Enum.GetValues(typeof(Cities)))
            {
                Console.WriteLine(std);
            }

            Console.ReadLine();
        }
    }

    struct Student
    {
        int rno;
        string name;
        char gender;
        long mno;
        public Student(int rno,string name,char gender,long mno)
        {
            this.rno = rno;
            this.name = name;
            this.gender = gender;
            this.mno = mno;
        }

        public void display()
        {
            Console.WriteLine("Roll No : {0}",rno);
            Console.WriteLine("Name : {0}",name);
            Console.WriteLine("Gender : {0}",gender);
            Console.WriteLine("Mobile No : {0}",mno);
        }
    }

    enum Cities
    {
        Pune=020,Mumbai=022,Ludhiana=0161,Lucknow=0522,Nasik=0253
    }
}
