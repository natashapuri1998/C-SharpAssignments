﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************** PROGRAM SUM SINGLE DIMENSION ****************");
            SumSingleDim ssd = new SumSingleDim();
            ssd.SingleDim();
            Console.WriteLine("************** PROGRAM DIAGONAL SUM ****************");
            DiagonalSum ds = new DiagonalSum();
            ds.DiagSum();
            Console.WriteLine("************** PROGRAM SUM OF ROWS ****************");
            SumOfRows sor = new SumOfRows();
            sor.SumRow();
            Console.WriteLine("************** PROGRAM JAGGED ARRAY ****************");
            JaggedArray ja = new JaggedArray();
            ja.JaggedSearch();
            Console.WriteLine("************** PROGRAM ASCII CONVERT ****************");
            AsciiConvert ac = new AsciiConvert();
            ac.AsciiValues();
            Console.ReadLine();
        }
    }
}
