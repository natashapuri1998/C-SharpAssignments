﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession5
{
    class JaggedArray
    {
        public void JaggedSearch()
        {
            int[][] a= new int[2][];
            a[0] = new int[] { 10, 20, 30, 40 };
            a[1] = new int[] { 50, 60 };
            Console.WriteLine("Array:");
            for (int i = 0; i < 2; i++)
            {
                foreach (int temp in a[i])
                {
                    Console.Write("{0} \t", temp);
                }
                Console.WriteLine();
            }

                    Console.WriteLine("Enter element:");
            int element = Convert.ToInt32(Console.ReadLine());
            int found = 0;
            for(int i=0;i<2;i++)
            {
                foreach(int temp in a[i])
                {
                    if(element==temp)
                    {
                        found = 1;
                        break;
                    }
                            
                }
            }
            if(found==1)
            {
                Console.WriteLine("{0} Element Found", element);
            }
            else
            {
                Console.WriteLine("Element Not Found");
            }
            Console.ReadLine();
        }
    }
}
