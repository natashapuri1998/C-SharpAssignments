﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession5
{
    class DiagonalSum
    {
        public void DiagSum()
        {
            int sum = 0;
            int[,] a = { { 10,40,50}, {60,20,70}, {80,90,30} };
            Console.WriteLine("Array:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0} \t", a[i, j]);
                }
                Console.WriteLine();
            }
            for (int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    if(i==j)
                    {
                        sum = sum + a[i,j];
                    }

                }
            }
            Console.WriteLine("Diagonal Sum: {0}",sum);
            Console.ReadLine();
        }
    }
}
