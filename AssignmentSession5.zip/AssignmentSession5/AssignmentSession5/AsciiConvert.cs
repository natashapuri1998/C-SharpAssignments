﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession5
{
    class AsciiConvert
    {
        public void AsciiValues()
        {
            char[,] a= { { 'a','b','c'}, {'d','e','f' }, {'g','h','i' } };
            Console.WriteLine("Character Array:");
            for(int i=0;i<3;i++)
            {
                for(int j=0;j<3;j++)
                {
                    Console.Write("{0} \t", a[i, j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine("After Conversion:");
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    Console.Write("{0} \t", Convert.ToInt32( a[i, j]));
                }
                Console.WriteLine();
            }

        }
    }
}
