﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssignmentSession5
{
    class SumSingleDim
    {
        public void SingleDim()
        {
            Console.WriteLine("Enter the size of array:");
            int size = Convert.ToInt32(Console.ReadLine());
            int[] array = new int[size];
            Console.WriteLine("Enter the elements of array:");
            for (int i = 0; i < size; i++)
            {
                array[i] = Convert.ToInt32(Console.ReadLine());
            }
            int sum = 0;
            Console.WriteLine("Sum of array:");
            for (int i = 0; i < size; i++)
            {
                sum = sum + array[i];

            }
            Console.WriteLine(sum);
            Console.ReadLine();
        }
    }
}
